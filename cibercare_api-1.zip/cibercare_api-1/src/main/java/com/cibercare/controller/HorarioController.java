package com.cibercare.controller;

import com.cibercare.model.Cita;
import com.cibercare.model.Horario;
import com.cibercare.repository.IHorarioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/horarios")
@CrossOrigin(origins = "*")
public class HorarioController {

    @Autowired
    private IHorarioRepository horarioRepository;

    
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public List<Horario> listarHorarios() {
        return horarioRepository.findAll();
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR')")
    @GetMapping("/doctor/{doctorId}")
    public List<Horario> listarHorariosPorDoctor(@PathVariable Long doctorId) {
        return horarioRepository.findByDoctorId(doctorId);
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR')")
    @PostMapping
    public ResponseEntity<?> crearHorario(@RequestBody Horario horario) {
        if (horario.getDoctor() == null || horario.getDoctor().getId() == null) {
            return ResponseEntity.badRequest().body("Debe especificar el ID del doctor");
        }
        Horario nuevoHorario = horarioRepository.save(horario);
        return ResponseEntity.ok(nuevoHorario);
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR')")
    @PutMapping("/{id}/disponibilidad")
    public ResponseEntity<?> cambiarDisponibilidad(@PathVariable Long id, @RequestParam boolean disponible) {
        Horario horario = horarioRepository.findById(id)
                .orElse(null);

        if (horario == null) {
            return ResponseEntity.notFound().build();
        }

        horario.setDisponible(disponible);
        horarioRepository.save(horario);
        return ResponseEntity.ok(horario);
    }


    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR')")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarHorario(@PathVariable Long id) {
        if (!horarioRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        horarioRepository.deleteById(id);
        return ResponseEntity.ok("Horario eliminado correctamente");
    }
}
