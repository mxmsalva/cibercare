package com.cibercare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cibercare.model.Cita;

public interface ICitaRepository extends JpaRepository<Cita, Long>{
	 List<Cita> findByPacienteId(Long pacienteId);
	    List<Cita> findByDoctorId(Long doctorId);
}
